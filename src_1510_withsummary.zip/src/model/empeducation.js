export default class EmployeeDocument{
  constructor(){
    {
      this.empId= 0;
      this.empEducationId= 0;
      this.degreeName= '';
      this.degreeYear= '';
      this.degreeUniversity= '';
      this.comments= '';
  }
}}
