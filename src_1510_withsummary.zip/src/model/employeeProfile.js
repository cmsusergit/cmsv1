export default class EmployeeProfile{
  constructor(){
    {
this.empId= 0;
this.title= 'Mr.';
this.firstName= '';
this.middleName= '';
this.lastName= '';
this.designationId= 0;
this.deptId= '';
this.doj= new Date();
this.email='';

this.gender= 'Male';
this.fatherName= '';
this.address= '';
this.nationality= 'Indian';
this.religion= 'Hindu';
this.category= 'Open';
this.dob= new Date('2001-01-01');
this.bloodGroup= '-';
this.marritalStatus= 'Married';
this.isTeaching= 1;
this.empCode= '';
this.panNumber= '';
this.pfNumber= '';
this.aadharNumber= '';
this.uanNumber= '';
  }
}}
